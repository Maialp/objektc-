#pragma once
#include "std_lib_facilities.h"

void playMastermind();

int checkCharactersAndPosition(string correct, string guess);
int ceckCharacters(string correct, string guess);
