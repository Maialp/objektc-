#pragma once

void testCallByValue();

void testCallByRefrence();

void testString();