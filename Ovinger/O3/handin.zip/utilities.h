#pragma once 

//a) 
int randomWithLimits(int rand_min ,int rand_max);

void playTargetPractice();