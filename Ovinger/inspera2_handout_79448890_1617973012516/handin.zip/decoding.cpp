#include "decoding.h"

#include <iostream>
#include <fstream>
#include <algorithm>

	
void decoding(string inFileName, string outFileName){
    //Begin task K1

    //End task K1
}
