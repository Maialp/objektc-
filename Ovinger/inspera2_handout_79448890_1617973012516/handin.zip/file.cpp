#include "file.h"

void testWriteToFile(){
    //Begin task F2

    //End task F2
}