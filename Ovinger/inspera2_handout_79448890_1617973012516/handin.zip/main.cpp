#include "case.h"
#include "file.h"
#include "decoding.h"
#include "case_gui.h"

int main(){
    // width, height and startPoint are for making a SearchWindow (gui)
    constexpr int width{800};
	constexpr int height{700};
	Point startPoint{100,100};

    //test you code here:
    
	return gui_main();
}