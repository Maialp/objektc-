#pragma once
#include <string>

using namespace std;

	
void decoding(string inFileName, string outFileName);