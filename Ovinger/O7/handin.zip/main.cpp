#include "std_lib_facilities.h"
#include "animal.h"
#include "Graph.h"



/* int main()
{
	Graph_lib::Vector_ref<Animal> animalVec; 
	Dog faro("Faro", 10);
	Cat pus("Pus", 2);
	animalVec.push_back(faro);
	animalVec.push_back(pus);

	for(int i = 0; i < animalVec.size();++i){
		cout << animalVec[i].toString() << endl;
	}
	

	keep_window_open();
} */