#pragma once 
#include "std_lib_facilities.h"

class Animal{
    protected:
        string name; 
        int age;
    public:
        Animal(string anmialName, int animalAge){name=anmialName; age= animalAge;};
        virtual string toString() = 0;
};

class Dog : public Animal{
    public:
        Dog(string animalName, int animalAge):Animal(animalName, animalAge){};
        string toString();
};

class Cat : public Animal{
    public:
        Cat(string animalName, int animalAge):Animal(animalName, animalAge){};
        string toString();
};

void testAnimal();