#pragma once

void drawNTNULogo(); 

