

#include "std_lib_facilities.h"
#include "survey2021.h"
#include "vehicle.h"
#include "NTNULogo.h"



int main()
{
	

	keep_window_open();
}

