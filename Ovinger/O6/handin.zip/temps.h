#pragma once
#include "std_lib_facilities.h"
#include "file.h"
#include "emnekatalog.h"

class Temps{
    private:
        double max;
        double min;
    public:
        Temps(){};
        friend istream& operator>>(istream& is, Temps& t);
        vector<Temps> readTemps(string fileName);
        void tempStats(vector<Temps> tempVec);
};