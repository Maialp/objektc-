#pragma once
#include "std_lib_facilities.h"


//Oppg 1 a) 

void readToFile(string fileName);

//Oppg 1 b) 
void readFromFile(string fromFile, string toFile);

//Oppg 2 a) 
vector<int> charCount(string fileName);
void printCharCount(vector<int> charCount);